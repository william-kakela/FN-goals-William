
export {displayTargetsOfTheGoal};

async function displayTargetsOfTheGoal(goalCode) {
    const target_URL = `https://unstats.un.org/SDGAPI/v1/sdg/Goal/${goalCode}/Target/List?&includechildren=true`;
     const response = await fetch(target_URL);
     const data = await response.json(); 
     console.log('targets: ', data);
     showTargets(data);
}


function showTargets(targets) {
    let targetsWrapperElem = document.querySelector('#read-more');
    targetsWrapperElem.innerHTML = ''; 

    const realTargets = targets[0].targets;

    for (let realTarget of realTargets) {

        console.log('subcode: ', realTarget);

        const codeTargetElem = document.createElement('h3');
        codeTargetElem.innerHTML = ' Show Code: ' + realTarget.code;
        targetsWrapperElem.append(codeTargetElem);

        const descriptionTargetElem = document.createElement('p');
        descriptionTargetElem.innerHTML = 'Description: ' + realTarget.description;
        targetsWrapperElem.append(descriptionTargetElem);
    }

}

document.querySelector('#close').addEventListener('click', function() {
document.getElementById("target_page").style.display = "none";
});