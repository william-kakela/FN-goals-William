const base_url = 'https://unstats.un.org/SDGAPI';
const list_url = '/v1/sdg/Goal/List?';
const GOAL_TARGET_LIST_URL = 'https://unstats.un.org/SDGAPI/v1/sdg/Goal/1/Target/List?includechildren=true';
 

document.querySelector('body').onload = showFnGoals();

async function showFnGoals() {
   let url = base_url + list_url;
    const response = await fetch(url);
    const data = await response.json();
    displayGoals (data);
}

function displayGoals(goals) {
    const goalswrapperElem = document.querySelector('#FN_Goals');
    goalswrapperElem.innerHTML = '';
    

    // loopar igenom målen
    for(let goal of goals) {
        const codeElem = document.createElement('h2');
        codeElem.innerHTML = goal.title;
        let goalCode = goal.code;
        goalswrapperElem.append(codeElem);
        let goalElem = document.createElement('p');
        goalElem.innerHTML=' click here to read more';
        goalswrapperElem.append(goalElem);
    
        goalElem.addEventListener('click', function () {
        console.log('Du klickade på: ', goal);
        document.getElementById('target_page').style.display = "block";
        displayTargetsOfTheGoal(goalCode);
    });
    }
    }

    //delade upp min kod här, den hämtar den första delen av koden nu som visar målen och nästa del är targetsen som dyker upp i en overlay.
    //Jag valde att dela den här för att separera koden så att man ser koden som körs i första delen av sidan.
    // klickar man på read more kommer min targets kod för att enklare kunna läsa koden. 
    
    
    import {displayTargetsOfTheGoal} from './indexFNtargets.js';
    
    
    